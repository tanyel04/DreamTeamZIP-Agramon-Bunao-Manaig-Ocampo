let menu = document.querySelector('#menu-icon');
let navlist = document.querySelector('.navlist');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navlist.classList.toggle('open');
};

window.onscroll = () => {
    menu.classList.remove('bx-x');
    navlist.classList.remove('open');
};

const sr = ScrollReveal ({
    distance: '70px',
    duration: 2700,
    reset: true
});

sr.reveal('.hero',{delay:200, origin: 'left'});
sr.reveal('.hero-img',{delay:350, origin: 'right'});


